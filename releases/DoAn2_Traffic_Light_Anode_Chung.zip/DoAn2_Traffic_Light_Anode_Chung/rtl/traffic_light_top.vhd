--------------------------------------------------------------------------------
-- DU AN: THIET KE HE THONG DIEU KHIEN DEN GIAO THONG NGA TU TREN FPGA CYCLONE IV
-- MODULE: traffic_light_top (MODULE DINH KET NOI HE THONG & QUET LED DYNAMIC)
--
-- MUC DICH HOC TAP:
--   1. Hoc cach ghep noi kien truc phan tang (Structural Modeling): Ket noi 4 module
--      con (clk_divider, fsm_controller, timer_counter, seg7_decoder) lai thanh 1 he thong.
--   2. Hieu ro ky thuat quet da kenh LED 7 doan (Dynamic Scanning Multiplexing):
--      Quet luon phien giua chu so Hang Chuc va Hang Don Vi voi tan so 1 kHz. Nho hien tuong
--      luu anh quang hoc cua mat nguoi, ta thay ca 2 so sang lien tuc ma van tiet kiem
--      duoc 50% so luong chan I/O tren FPGA!
--   3. Tich hop Mach khoa an toan phan cung (Fail-safe Hardware Interlock):
--      Tu dong ngat ca 2 den xanh va ep bat 2 den do neu he thong bi loi logic, ngan chan
--      tuyet doi nguy co tai nan xe co o nga tu.
--------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all; -- Thu vien logic co ban
use ieee.numeric_std.all;    -- Thu vien toan hoc so hoc

entity traffic_light_top is
    generic (
        -- Tham so mo phong: mac dinh la false (chay that tren phan cung)
        SIMULATION : boolean := false
    );
    port (
        -- 1. Xung nhap thach anh master 50 MHz tu kit FPGA (PIN_24 hoac PIN_23)
        CLOCK_50  : in  std_logic;

        -- 2. Cac nut nhan dieu khien ngoai vi (Active-Low: Bam nut la muc '0')
        --    KEY(0): Nut Reset toan he thong (Altium: PIN_58)
        --    KEY(1): Nut uu tien khan cap Lan A (Altium: PIN_60)
        --    KEY(2): Nut uu tien khan cap Lan B (Altium: PIN_65)
        KEY       : in  std_logic_vector(2 downto 0);

        -- 3. Cac cong tac gat che do hoat dong (Active-Low kem tro keo len noi)
        --    SW(0): Cong tac che do ban dem (Altium: PIN_67 - MTS-103)
        --    SW(1): Cong tac tam dung bo dem (Altium: PIN_69 - MTS-103)
        SW        : in  std_logic_vector(1 downto 0);

        -- 4. Tin hieu dieu khien den giao thong (Active-High: '1' la sang den)
        --    LEDR(0): Den VANG Lan A (PIN_43)   |   LEDR(1): Den DO Lan A (PIN_46)
        --    LEDR(2): Den VANG Lan B (PIN_52)   |   LEDR(3): Den DO Lan B (PIN_54)
        LEDR      : out std_logic_vector(3 downto 0);

        --    LEDG(0): Den XANH Lan A (PIN_39)   |   LEDG(1): Den XANH Lan B (PIN_50)
        LEDG      : out std_logic_vector(1 downto 0);

        -- 5. Cung cap tin hieu cho LED 7 doan Lan A (qua ULN2803A)
        --    HEX_A_SEG: 7 thanh doan a..g (PIN_129, 133, 136, 138, 142, 144, 143)
        --    HEX_A_DIG: DIG(0)=Don vi (PIN_137), DIG(1)=Chuc (PIN_141)
        HEX_A_SEG : out std_logic_vector(6 downto 0);
        HEX_A_DIG : out std_logic_vector(1 downto 0);

        -- 6. Cung cap tin hieu cho LED 7 doan Lan B (qua ULN2803A)
        --    HEX_B_SEG: 7 thanh doan a..g (PIN_111, 113, 119, 121, 125, 127, 110)
        --    HEX_B_DIG: DIG(0)=Don vi (PIN_112), DIG(1)=Chuc (PIN_115)
        HEX_B_SEG : out std_logic_vector(6 downto 0);
        HEX_B_DIG : out std_logic_vector(1 downto 0)
    );
end entity traffic_light_top;

architecture structural of traffic_light_top is

    -- 10 ms stable input qualification at 50 MHz; shortened only for simulation.
    function debounce_cycles(sim : boolean) return positive is
    begin
        if sim then return 3; else return 500000; end if;
    end function;
    constant DEBOUNCE_LIMIT : positive := debounce_cycles(SIMULATION);
    signal reset_meta, reset_sync : std_logic := '0';
    signal reset_count : natural range 0 to DEBOUNCE_LIMIT - 1 := 0;
    signal rst_n_s : std_logic := '0';
    signal control_meta, control_sync, control_clean : std_logic_vector(3 downto 0) := (others => '1');
    type debounce_counts is array (0 to 3) of natural range 0 to DEBOUNCE_LIMIT - 1;
    signal control_count : debounce_counts := (others => 0);
    attribute altera_attribute : string;
    attribute altera_attribute of reset_meta, reset_sync, control_meta, control_sync : signal is
        "-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS";

    -- =========================================================================
    -- CAC DUONG DAY TIN HIEU NOI BO (INTERNAL CONNECTING SIGNALS)
    -- Dong vai tro nhu cac day dong ket noi giua cac IC chuc nang
    -- =========================================================================
    signal xung_tick_1hz_s : std_logic;                    -- Day truyen xung kich 1Hz tu clk_divider sang timer_counter
    signal xung_chop_1hz_s : std_logic;                    -- Day truyen xung vuong 1Hz tu clk_divider sang fsm_controller
    signal co_het_gio_s    : std_logic;                    -- Day bao het gio tu timer_counter sang fsm_controller
    signal chon_pha_s      : std_logic_vector(1 downto 0); -- Day bao ma pha tu fsm sang timer
    signal nap_pha_s       : std_logic;                    -- Day phat xung nap so giay tu fsm sang timer
    signal tat_seg7_s      : std_logic;                    -- Day bao tat man hinh tu fsm sang bo giai ma 7 doan

    -- Tin hieu chua ma BCD 4-bit thoi gian
    signal bcd_a_chuc_s    : std_logic_vector(3 downto 0); -- Chu so hang chuc Lan A
    signal bcd_a_don_vi_s  : std_logic_vector(3 downto 0); -- Chu so hang don vi Lan A
    signal bcd_b_chuc_s    : std_logic_vector(3 downto 0); -- Chu so hang chuc Lan B
    signal bcd_b_don_vi_s  : std_logic_vector(3 downto 0); -- Chu so hang don vi Lan B

    -- Tin hieu cong tac gat da qua dao logic (Active-Low kem tro keo len noi)
    signal sw_ban_dem_s    : std_logic; -- '1' khi noi SW(0) xuong GND, '0' khi de ho
    signal sw_tam_dung_s   : std_logic; -- '1' khi noi SW(1) xuong GND, '0' khi de ho

    -- Tin hieu den tho tu FSM truoc khi qua mach khoa an toan Interlock
    signal den_do_a_s      : std_logic;
    signal den_vang_a_s    : std_logic;
    signal den_xanh_a_s    : std_logic;
    signal den_do_b_s      : std_logic;
    signal den_vang_b_s    : std_logic;
    signal den_xanh_b_s    : std_logic;

    -- =========================================================================
    -- CAC TIN HIEU DUNG CHO BO QUET DYNAMIC SCANNING 1 KHZ
    -- =========================================================================
    -- Nguong dem bo quet LED 7 doan:
    -- Khi chay thuc te tren chip: 50.000 chu ky (50 MHz / 50.000 = 1 kHz doi vi tri, 500 Hz tan so quet)
    -- Khi mo phong ModelSim: rut ngan con 5 chu ky (0 den 4) de quan sat ro chuyen doi 2 digit
    function lay_nguong_quet(co_mo_phong : boolean) return natural is
    begin
        if co_mo_phong then
            return 5;     -- 5 chu ky trong mo phong
        else
            return 50000; -- 50.000 chu ky tren phan cung
        end if;
    end function;

    constant NGUONG_BO_DEM_QUET : natural := lay_nguong_quet(SIMULATION);

    -- Bo dem chu ky clock cho mach quet LED 7 doan
    signal bo_dem_quet     : natural range 0 to NGUONG_BO_DEM_QUET - 1 := 0;

    -- Bit chon vi tri LED: '0' la hien thi hang Don vi, '1' la hien thi hang Chuc
    signal chon_vi_tri_led : std_logic := '0';

    -- Bus du lieu BCD sau khi qua bo ghep kenh MUX 2-sang-1
    signal bcd_a_mux       : std_logic_vector(3 downto 0);
    signal bcd_b_mux       : std_logic_vector(3 downto 0);

begin

    -- KEY0 asserts reset immediately. Release requires two synchronization
    -- stages followed by a stable high interval (also rejects reset bounce).
    process(CLOCK_50, KEY(0))
    begin
        if KEY(0) = '0' then
            reset_meta <= '0'; reset_sync <= '0';
            reset_count <= 0; rst_n_s <= '0';
        elsif rising_edge(CLOCK_50) then
            reset_meta <= '1'; reset_sync <= reset_meta;
            if reset_sync = '0' then
                reset_count <= 0; rst_n_s <= '0';
            elsif reset_count = DEBOUNCE_LIMIT - 1 then
                rst_n_s <= '1';
            else
                reset_count <= reset_count + 1;
            end if;
        end if;
    end process;

    -- Each control is qualified independently, on both press and release.
    process(CLOCK_50, rst_n_s)
    begin
        if rst_n_s = '0' then
            control_meta <= (others => '1');
            control_sync <= (others => '1');
            control_clean <= (others => '1');
            control_count <= (others => 0);
        elsif rising_edge(CLOCK_50) then
            control_meta <= SW & KEY(2 downto 1);
            control_sync <= control_meta;
            for i in 0 to 3 loop
                if control_sync(i) = control_clean(i) then
                    control_count(i) <= 0;
                elsif control_count(i) = DEBOUNCE_LIMIT - 1 then
                    control_clean(i) <= control_sync(i);
                    control_count(i) <= 0;
                else
                    control_count(i) <= control_count(i) + 1;
                end if;
            end loop;
        end if;
    end process;

    -- =========================================================================
    -- KHOI 1: GHEP NOI BO CHIA TAN SO (clk_divider)
    -- =========================================================================
    khoi_chia_tan: entity work.clk_divider
        generic map (
            SIMULATION => SIMULATION -- Truyen tham so mo phong vao
        )
        port map (
            clk_50m       => CLOCK_50,
            rst_n         => rst_n_s,
            nap_lai_giay  => nap_pha_s,
            tam_dung      => sw_tam_dung_s,
            xung_tick_1hz => xung_tick_1hz_s,
            xung_chop_1hz => xung_chop_1hz_s
        );

    -- Dao logic cong tac de ho tro tro keo len noi (Active-Low):
    -- Khi de ho: SW = '1' -> tin hieu dieu khien = '0' (Khong bat ban dem, khong tam dung)
    -- Khi noi GND: SW = '0' -> tin hieu dieu khien = '1' (Kich hoat ban dem hoac tam dung)
    sw_ban_dem_s  <= not control_clean(2);
    sw_tam_dung_s <= not control_clean(3);

    -- =========================================================================
    -- KHOI 2: GHEP NOI BO DIEU KHIEN FSM (fsm_controller)
    -- =========================================================================
    khoi_dieu_khien_fsm: entity work.fsm_controller
        port map (
            clk_50m          => CLOCK_50,
            rst_n            => rst_n_s,
            xung_chop_1hz    => xung_chop_1hz_s,
            co_het_gio       => co_het_gio_s,
            sw_ban_dem       => sw_ban_dem_s,
            sw_tam_dung      => sw_tam_dung_s,
            key_khan_cap_a_n => control_clean(0),
            key_khan_cap_b_n => control_clean(1),
            chon_pha         => chon_pha_s,
            nap_pha          => nap_pha_s,
            tat_seg7         => tat_seg7_s,
            den_do_a         => den_do_a_s,
            den_vang_a       => den_vang_a_s,
            den_xanh_a       => den_xanh_a_s,
            den_do_b         => den_do_b_s,
            den_vang_b       => den_vang_b_s,
            den_xanh_b       => den_xanh_b_s
        );

    -- =========================================================================
    -- KHOI 3: GHEP NOI BO DEM LUI THOI GIAN & BCD (timer_counter)
    -- =========================================================================
    khoi_dem_thoi_gian: entity work.timer_counter
        port map (
            clk_50m       => CLOCK_50,
            rst_n         => rst_n_s,
            xung_tick_1hz => xung_tick_1hz_s,
            tam_dung      => sw_tam_dung_s,
            nap_pha       => nap_pha_s,
            chon_pha      => chon_pha_s,
            co_het_gio    => co_het_gio_s,
            bcd_a_chuc    => bcd_a_chuc_s,
            bcd_a_don_vi  => bcd_a_don_vi_s,
            bcd_b_chuc    => bcd_b_chuc_s,
            bcd_b_don_vi  => bcd_b_don_vi_s
        );

    -- =========================================================================
    -- KHOI 4: MACH QUET DYNAMIC SCANNING 1 KHZ CHO LED 7 DOAN
    -- Moi chu ky 1 ms (50.000 xung 50MHz), tin hieu chon_vi_tri_led dao trang thai
    -- giup chuyen doi qua lai giua chu so Don vi va chu so Chuc voi toc do cuc nhanh
    -- =========================================================================
    process(CLOCK_50, rst_n_s)
    begin
        if rst_n_s = '0' then
            bo_dem_quet     <= 0;
            chon_vi_tri_led <= '0';
        elsif rising_edge(CLOCK_50) then
            if bo_dem_quet = NGUONG_BO_DEM_QUET - 1 then
                bo_dem_quet     <= 0;
                chon_vi_tri_led <= not chon_vi_tri_led; -- Dao vi tri: 0 sang 1, 1 ve 0
            else
                bo_dem_quet     <= bo_dem_quet + 1;
            end if;
        end if;
    end process;

    -- Bo ghep kenh MUX 2-sang-1 lua chon du lieu BCD can giai ma:
    -- Khi chon_vi_tri_led = '0': Lay so hang Don vi
    -- Khi chon_vi_tri_led = '1': Lay so hang Chuc
    bcd_a_mux <= bcd_a_don_vi_s when chon_vi_tri_led = '0' else bcd_a_chuc_s;
    bcd_b_mux <= bcd_b_don_vi_s when chon_vi_tri_led = '0' else bcd_b_chuc_s;

    -- Dieu khien chan chon vi tri LED (DIGIT SELECT - Anode chung: cap 3.3V muc 1 vao cuc Duong chung):
    -- Khi chon_vi_tri_led = '0': Lay so hang Don vi -> Xuat '1' (3.3V) vao DIG Don vi
    -- Khi chon_vi_tri_led = '1': Lay so hang Chuc   -> Xuat '1' (3.3V) vao DIG Chuc
    -- Khi tat_seg7_s = '1' (Ban dem): Xuat '0' de ngat nguon ca 2 vi tri LED
    HEX_A_DIG(0) <= '1' when (chon_vi_tri_led = '0' and tat_seg7_s = '0') else '0'; -- Bat LED Don vi Lan A (Cap 3.3V Anode)
    HEX_A_DIG(1) <= '1' when (chon_vi_tri_led = '1' and tat_seg7_s = '0') else '0'; -- Bat LED Chuc Lan A (Cap 3.3V Anode)
    HEX_B_DIG(0) <= '1' when (chon_vi_tri_led = '0' and tat_seg7_s = '0') else '0'; -- Bat LED Don vi Lan B (Cap 3.3V Anode)
    HEX_B_DIG(1) <= '1' when (chon_vi_tri_led = '1' and tat_seg7_s = '0') else '0'; -- Bat LED Chuc Lan B (Cap 3.3V Anode)

    -- =========================================================================
    -- KHOI 5: GHEP NOI 2 BO GIAI MA 7 DOAN CHO LAN A VA LAN B
    -- Nho co ky thuat quet da kenh, ta chi can 2 IC giai ma thay vi can toi 4 IC!
    -- =========================================================================
    khoi_giai_ma_hex_a: entity work.seg7_decoder
        port map (
            bcd_vao => bcd_a_mux,
            tat_led => tat_seg7_s,
            seg7_ra => HEX_A_SEG
        );

    khoi_giai_ma_hex_b: entity work.seg7_decoder
        port map (
            bcd_vao => bcd_b_mux,
            tat_led => tat_seg7_s,
            seg7_ra => HEX_B_SEG
        );

    -- =========================================================================
    -- KHOI 6: MACH KHOA AN TOAN PHAN CUNG (FAIL-SAFE HARDWARE INTERLOCK)
    -- Giam sat tin hieu den tho tu FSM. Neu xay ra tinh huong nguy hiem:
    --   - Ca 2 lan deu XANH (Dual-Green conflict)
    --   - Hoac 1 lan XANH trong khi lan kia VANG (Green-Yellow conflict)
    -- Mach phan cung lap tuc can thiep: Ngat toan bo den xanh/vang va ep bat 2 den do de chong dam xe!
    -- =========================================================================
    process(den_xanh_a_s, den_xanh_b_s, den_vang_a_s, den_vang_b_s, den_do_a_s, den_do_b_s)
    begin
        -- Kiem tra tinh huong cam: Ca 2 lan deu XANH hoac 1 lan XANH trong khi lan kia VANG
        if (den_xanh_a_s = '1' and den_xanh_b_s = '1') or
           (den_xanh_a_s = '1' and den_vang_b_s = '1') or
           (den_vang_a_s = '1' and den_xanh_b_s = '1') then
            -- Kich hoat che do bao ve nguy cap:
            LEDG(0) <= '0'; -- Ep tat den XANH Lan A
            LEDG(1) <= '0'; -- Ep tat den XANH Lan B
            LEDR(0) <= '0'; -- Tat vang Lan A
            LEDR(1) <= '1'; -- Ep bat den DO Lan A
            LEDR(2) <= '0'; -- Tat vang Lan B
            LEDR(3) <= '1'; -- Ep bat den DO Lan B
        else
            -- Hoat dong binh thuong: Xuat truc tiep tin hieu den tu FSM ra cac cong
            LEDG(0) <= den_xanh_a_s; -- Den Xanh Lan A
            LEDG(1) <= den_xanh_b_s; -- Den Xanh Lan B
            LEDR(0) <= den_vang_a_s; -- Den Vang Lan A
            LEDR(1) <= den_do_a_s;   -- Den Do Lan A
            LEDR(2) <= den_vang_b_s; -- Den Vang Lan B
            LEDR(3) <= den_do_b_s;   -- Den Do Lan B
        end if;
    end process;

end architecture structural;
